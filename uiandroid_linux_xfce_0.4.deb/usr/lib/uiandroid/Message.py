#!/bin/python3

# import module gtk
import sys
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

# param
try:
  param1 = sys.argv[1]
  param2 = sys.argv[2]
  
except:
	print("usage : /path/message.py [title] [text]")
	exit()
	
# open window
win = Gtk.Window()
win.set_title(str(param1))
win.set_default_size(200, 30)
win.set_position(Gtk.WindowPosition.MOUSE)

# window content
show_message = Gtk.MenuItem()
show_message.set_label(str(param2))
win.add(show_message)
	
# close window
win.set_icon_from_file("/usr/share/icons/hicolor/scalable/apps/warning_logo.svg")
win.connect("delete-event", Gtk.main_quit)
win.show_all()
Gtk.main()
