#!/bin/bash

# need package aapt from termux
path_termux="/data/data/com.termux/files/usr"
path=/usr/lib/uiandroid/tsa

if [ -d $path ];then
	cd $path
else
	echo "dir <[$path]> not found"; exit
fi

package=( $(cat pkg_app.txt) )

if [[ $1 == "name" ]] && [ $2 ] && [ -z $3 ];then
	adb shell su -c "$path_termux/bin/aapt d badging $(adb shell pm path $2 | grep base.apk | cut -d ':' -f 2) | grep label: | cut -d \"'\" -f 2" | tee app.txt
elif [[ $1 == "pid" ]] && [ $2 ] && [ -z $3 ];then
	adb shell ps -A | grep $2 | awk '{print $2}' | tee pid.txt
elif [[ $1 == "add" ]] && [ $2 ] && [ -z $3 ];then
	# check app already used
	for check in ${package[@]};do
		if [[ $2 == $check ]];then
			echo "pkg <[$2]> already used"; exit
		fi
	done
	
	# add package to list app
	pkg_list=( $(adb shell pm list packages | cut -d ':' -f 2) )
	for list in ${pkg_list[@]};do
		if [[ $list == $2 ]];then
			echo $2 | tee -a pkg_app.txt
		fi
	done
else
	# check devices
	if [ -z "$(adb devices -l | grep product:)" ];then
		echo "0" | tee device.txt
		exit
	else
		echo "1" | tee device.txt
	fi
	
	# get all app running
	adb shell ps -A | grep com | cut -d '/' -f 1 | cut -d '[' -f 1 | sed '/^[[:blank:]]*$/d' | awk '{print $9}' | tee pkg_all_running.txt
	if [ -f pkg_running.txt ];then
		rm pkg_running.txt; touch pkg_running.txt
	fi
	
	# get app running
	paket=( $(cat pkg_all_running.txt) )
	for i in ${package[@]};do
		for j in ${paket[@]};do
			if [[ $i == $j ]];then
				echo $i | tee -a pkg_running.txt
			fi
		done
	done
fi
