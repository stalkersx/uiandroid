device_nm = 1
mobile_data = 1
wifi_on = 0
bluetooth_on = 0
