#!/bin/python3

# import module gtk
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from gi.repository.GdkPixbuf import Pixbuf

# get directory lib
dir_ui = "/usr/lib/uiandroid"

# get status service
os.system("bash " + str(dir_ui) + "/nm/service_nm.sh")
import Statusnm

# create class window
class window(Gtk.Window):
		def __init__(self):
				Gtk.Window.__init__(self, title="Network_Manager Android")
				Gtk.Window.set_default_size(self, 200, 30)
				Gtk.Window.set_position(self, Gtk.WindowPosition.MOUSE)
				
				# create hbox
				hbox = Gtk.Box(spacing=4)
				
				# create button checklis
				bc1 = Gtk.CheckButton(label="Seluler")
				bc2 = Gtk.CheckButton(label="Wifi")
				bc3 = Gtk.CheckButton(label="Bluetooth")
				
				# function connection
				def check_connect(widget, connect) :
					if int(connect) == 1 :
						widget.set_active(True)
					else :
						widget.set_active(False)
				
				# check connection
				check_connect(bc1, Statusnm.mobile_data)
				check_connect(bc2, Statusnm.wifi_on)
				check_connect(bc3, Statusnm.bluetooth_on)
				
				# action checklis
				bc1.connect("toggled", self.click_seluler)
				bc2.connect("toggled", self.click_wifi)
				bc3.connect("toggled", self.click_bluetooth)
				
				# put button checklis to box
				hbox.pack_start(bc1, True, True, 0)
				hbox.pack_start(bc2, True, True, 0)
				hbox.pack_start(bc3, True, True, 0)
				
				# add box
				self.add(hbox)
				
		def click_seluler(self, click1) :
			if click1.get_active():
					os.system("adb shell su -c \"svc data enable\"")
			else :
					os.system("adb shell su -c \"svc data disable\"")
						
		def click_wifi(self, click2) :
			if click2.get_active():
				os.system("adb shell su -c \"svc wifi enable\"")
			else :
				os.system("adb shell su -c \"svc wifi disable\"")
				
		def click_bluetooth(self, click3) :
			if click3.get_active():
				os.system("adb shell su -c \"svc bluetooth enable\"")
			else :
				os.system("adb shell su -c \"svc bluetooth disable\"")
				
# check devices
if int(Statusnm.device_nm) == 0 :
	# notif nothing devices
	warning = Gtk.ImageMenuItem()
	warning.set_label("Please Do Connection To Adb")
	
	# window nothing devices
	win = Gtk.Window()
	win.set_title("Network Manager Android")
	win.set_default_size(200, 30)
	win.set_position(Gtk.WindowPosition.MOUSE)
	win.add(warning)
	
else :
	win = window()

# close window
win.set_icon_from_file("/usr/share/icons/hicolor/scalable/apps/nm_logo.svg")
win.connect("delete-event", Gtk.main_quit)
win.show_all()
Gtk.main()
