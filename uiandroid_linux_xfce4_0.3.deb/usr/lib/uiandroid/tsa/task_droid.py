#!/bin/python3

# import module gtk
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

# box app_name
vbox1 = Gtk.VBox()

# path home
home = "/usr/lib/uiandroid"
			
# method app name
def add_app(pkg, box, loc) :

	# start service name
	os.system("bash " + loc + "/tsa/service_tsa.sh name " + pkg)
	
	# get app name
	name = open(loc + "/tsa/app.txt", "r").read()
	
	# method click
	def click_kill(widget) :
		
		# start proccess pid
		os.system("bash " + loc + "/tsa/service_tsa.sh pid " + pkg)
		
		# get pid
		pid_number = open(loc + "/tsa/pid.txt", "r").readlines()
		
		# kill proccess
		for pid in pid_number :
			os.system("adb shell su -c \"kill -SIGKILL " + pid.replace("\n","") + "\"")
		
	# item kill process
	exit_proses = Gtk.MenuItem()
	exit_proses.set_label("kill")
	exit_proses.connect("activate", click_kill)

	# menu proccess
	menu = Gtk.Menu()
	menu.append(exit_proses)

	# menu app
	mi = Gtk.MenuItem()
	mi.set_label(name.replace("\n",""))
	mi.set_submenu(menu)
	
	# menu bar proses
	mb = Gtk.MenuBar()
	mb.append(mi)
	
	# list app
	box.pack_start(mb, False, False, 0)

# run service
os.system("bash " + home + "/tsa/service_tsa.sh")

# get app_name
pkg_name = open(home + "/tsa/pkg_running.txt", "r").readlines()

# create widget app name
for package in pkg_name :
	add_app(package.replace("\n",""), vbox1, home)

# scroll window app
sw = Gtk.ScrolledWindow()
sw.add(vbox1)

# method send app input
def send_input(text) :
	os.system("bash " + home + "/tsa/service_tsa.sh add " + text.get_text())
	
# entry input
inp = Gtk.Entry()
inp.connect("activate", send_input)

# text info task
textview1 = Gtk.TextView()
textview1.set_editable(False) # edit text
textview1.set_cursor_visible(False) # garis tulis
textview1.get_buffer().set_text("Task Manager Android") # write text

# text check device
textview2 = Gtk.TextView()
textview2.set_editable(False) # edit text
textview2.set_cursor_visible(False) # garis tulis
textview2.get_buffer().set_text("Please Connect On Adb Device") # write text

# box window
vbox = Gtk.VBox()
vbox.pack_start(textview1, False, False, 0)
vbox.pack_start(sw, True, True, 0)
vbox.pack_start(inp, False, False, 0)

# open window
win = Gtk.Window()
win.set_title("Task Android")
win.set_icon_from_file("/usr/share/icons/hicolor/scalable/apps/tsa_logo.svg")
win.set_position(Gtk.WindowPosition.MOUSE)

# check device
device = open(home + "/tsa/device.txt").read()

if int(device.replace("\n","")) == 0 :
	win.set_default_size(200, 30)
	win.add(textview2)
else :
	win.set_default_size(200, 500)
	win.add(vbox)
	
# close window
win.connect("delete-event", Gtk.main_quit)
win.show_all()
Gtk.main()
