#!/bin/bash

# path to workdir
path="/usr/lib/uiandroid/nm"

# check connection adb
connect=$(adb devices -l | grep product)
echo $connect| exit
if [ -z "$connect" ];then
  echo "device_nm = 0" | tee $path/Statusnm.py
else
  echo "device_nm = 1" | tee $path/Statusnm.py
  # check network status
  echo "mobile_data = $(adb shell settings get global mobile_data)" | tee -a $path/Statusnm.py
  echo "wifi_on = $(adb shell settings get global wifi_on)" | tee -a $path/Statusnm.py
  echo "bluetooth_on = $(adb shell settings get global bluetooth_on)" | tee -a $path/Statusnm.py
fi
