device_nm = 1
mobile_data = 1
wifi_on = 1
bluetooth_on = 0
